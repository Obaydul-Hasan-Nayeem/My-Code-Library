#include <bits/stdc++.h>

using namespace std;

int main() {

    int ar[5] = {4, 6, 2, 7, -5};
    cout << ar << "\n";
    cout << ar + 1 << "\n";
    cout << ar + 2 << "\n";
    cout << ar + 3 << "\n";
    cout << ar + 4 << "\n";
    cout << ar + 5 << "\n";
    cout << ar + 6 << "\n";
    cout << ar + 7 << "\n";
    cout << ar + 7453 << "\n";
    cout << ar[5] << "\n";
    //cout << ar[44545] << "\n";

return 0;
}

/*
    Index Position of array: start address + index * 4
*/

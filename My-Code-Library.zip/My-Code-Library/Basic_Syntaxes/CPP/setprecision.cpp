#include <bits/stdc++.h>

using namespace std;

int main()
{
    double x = 34.343423534;
    cout << setprecision(3) << fixed << x << endl;

    return 0;
}

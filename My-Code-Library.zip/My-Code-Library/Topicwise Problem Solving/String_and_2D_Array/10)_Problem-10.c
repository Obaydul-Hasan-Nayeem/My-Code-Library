/// Problem Statement:
/*
How can you find the sum of digits of a number? Write a C program that will extract the digits of the given integer number as input and add them to find the required output. For example, if the input is 1235623, then the output will be 22. Because, 1+2+3+5+6+2+3 = 22.
*/

/// My Solution
There are some errors in the given statement. Such that:
We can not assign more than one character in a char type variable.  If we want to assign like this, we must declare a char type array (not variable).
There will be a semicolon (;) at the end of the line.
We have to use inverted commas like (� �), but not like (��).

 The statement after fixing the errors:
         char s[] = "america";




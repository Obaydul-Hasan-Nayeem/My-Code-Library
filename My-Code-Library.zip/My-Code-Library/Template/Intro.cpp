/*
    - template based stack implementation
*/

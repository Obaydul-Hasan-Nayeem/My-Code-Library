/*

STL:
    - container: vector, set, map, ...
    - iterators:
    - algorithm:
    - function:

# set

# substring
    string.substr(5, 3) --> extract 3 letters from the index 5


*/
